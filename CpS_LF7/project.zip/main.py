import machine
import dht
from ssd1306 import SSD1306_I2C


# Datenpin initialisieren
dataPin = machine.Pin(28, machine.Pin.IN, machine.Pin.PULL_UP)

#I2C initialisieren
i2c_dev = machine.I2C(1, scl=machine.Pin(27), sda=machine.Pin(26), freq=200000)


#Sensor (DHT22) initialisieren
sensor = dht.DHT22(dataPin)

#Display initialisieren

oled = SSD1306_I2C(128, 64, i2c_dev)

# Sensor messen lassen

sensor.measure()

# Messwerte ausgeben
print(sensor.temperature())
print(sensor.humidity())

temperature = sensor.temperature()
humidity = sensor.humidity()

oled.text(str(temperature),0,0)
oled.show()

while sensore.measure()
  if temperatue < 25
    lol
  if temperatue > 30
    lol
  else
    lol